#include "vex.h"

void default_constants(){
  // Each constant set is in the form of (maxVoltage, kP, kI, kD, startI).
  chassis.set_drive_constants(12, 2.5, 1.2, 1.2, 0);
  chassis.set_heading_constants(6, .4, 0, 1, 0);
  chassis.set_turn_constants(12, .34, .03, 2, 15); //chassis.set_turn_constants(12, .4, .03, 2, 15);
  chassis.set_swing_constants(8, .45, .001, 2, 15);

  // Each exit condition set is in the form (settle_error, settle_time, timeout).
  chassis.set_drive_exit_conditions(1, 180, 900);
  chassis.set_turn_exit_conditions(1, 180, 900);
  chassis.set_swing_exit_conditions(1, 180, 900);
}

void odom_constants(){
  default_constants();
  chassis.drive_max_voltage = 8;
  chassis.drive_settle_error = 3;
}

void drive_test(){
  chassis.drive_distance(6);
  wait(2, sec);
  chassis.drive_distance(12);
  wait(2, sec);
  chassis.drive_distance(18);
  wait(2, sec);
  chassis.drive_distance(-36);
}

void turn_test(){
  chassis.turn_to_angle(45);
  wait(2, sec);
  chassis.turn_to_angle(180);
  wait(2, sec);
  chassis.turn_to_angle(315);
  wait(2, sec);
  chassis.turn_to_angle(270);

}

void swing_test(){
  chassis.left_swing_to_angle(90);
  wait(2, sec);
  chassis.right_swing_to_angle(0);
}

void full_test(){
  chassis.drive_distance(24);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-36);
  chassis.right_swing_to_angle(-90);
  chassis.drive_distance(24);
  chassis.turn_to_angle(0);
}

void odom_test(){
  chassis.set_coordinates(0, 0, 0);
  while(1){
    Brain.Screen.clearScreen();
    Brain.Screen.printAt(0,50, "X: %f", chassis.get_X_position());
    Brain.Screen.printAt(0,70, "Y: %f", chassis.get_Y_position());
    Brain.Screen.printAt(0,90, "Heading: %f", chassis.get_absolute_heading());
    Brain.Screen.printAt(0,110, "ForwardTracker: %f", chassis.get_ForwardTracker_position());
    Brain.Screen.printAt(0,130, "SidewaysTracker: %f", chassis.get_SidewaysTracker_position());
    task::sleep(20);
  }
}

void tank_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.turn_to_point(24, 24);
  chassis.drive_to_point(24,24);
  chassis.drive_to_point(0,0);
  chassis.turn_to_angle(0);
}

void holonomic_odom_test(){
  odom_constants();
  chassis.set_coordinates(0, 0, 0);
  chassis.holonomic_drive_to_point(0, 18, 90);
  chassis.holonomic_drive_to_point(18, 0, 180);
  chassis.holonomic_drive_to_point(0, 18, 270);
  chassis.holonomic_drive_to_point(0, 0, 0);
}

void left_awp(){
  chassis.set_heading(0);
  chassis.drive_distance(-10);
  Flaps.set(true);
  chassis.drive_distance(5);
  chassis.right_swing_to_angle(-45);
  wait(0.2, sec);
  Flaps.set(false);
  chassis.turn_to_angle(180);
  chassis.drive_distance(13);
  chassis.left_swing_to_angle(225);
  Intake.spin(fwd, 100, percent);
  chassis.set_drive_exit_conditions(1.5, 180, 1100);
  chassis.drive_distance(25);
  Intake.stop();
  chassis.set_heading(0);
  chassis.drive_distance(-12);
  chassis.turn_to_angle(-45);
  chassis.drive_distance(-25);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(-30);
  chassis.drive_distance(3);
  chassis.turn_to_angle(0);
  chassis.drive_distance(15);
  Flaps.set(true);

}

void right_4_ball(){
  chassis.set_heading(0);
  Intake.spin(fwd, 100, percent);
  chassis.drive_distance(6);
  wait(0.2, sec);
  chassis.drive_distance(-31);
  chassis.turn_to_angle(145);
  Flaps.set(true);
  chassis.drive_distance(16);
  chassis.set_swing_constants(12, .45, .001, 2, 15);
  chassis.right_swing_to_angle(110);
  chassis.set_swing_constants(8, .45, .001, 2, 15);
  Flaps.set(false);
  chassis.drive_distance(25);
  chassis.drive_distance(-10);
  chassis.turn_to_angle(12);
  chassis.set_drive_exit_conditions(1.5, 180, 1100);
  chassis.drive_distance(53);
  chassis.set_drive_exit_conditions(1.5, 180, 900);
  chassis.drive_distance(-10);
  Intake.stop();
  chassis.turn_to_angle(155);
  Intake.spin(reverse, 100, percent);
  chassis.drive_distance(10);
  Intake.stop();
  chassis.turn_to_angle(47);
  Intake.spin(fwd, 100, percent);
  chassis.drive_distance(21);
  wait(0.4, sec);
  chassis.drive_distance(-13);
  chassis.left_swing_to_angle(180);
  Flaps.set(true);
  chassis.drive_distance(48);
  Flaps.set(false);
  chassis.drive_distance(-20);
}

void right_5_ball(){
  chassis.set_heading(0);
  Flaps.set(true);
  chassis.drive_distance(-12.5);
  Flaps.set(false);
  wait(0.1, sec);
  chassis.left_swing_to_angle(-40);
  chassis.drive_distance(-18.5);
  chassis.set_heading(0);
  chassis.left_swing_to_angle(105);
  Intake.spin(fwd, 100, percent);
  chassis.drive_distance(41);
  wait(0.4, sec);
  chassis.right_swing_to_angle(215);
  Intake.stop();
  Intake.spin(reverse, 50, percent);
  chassis.drive_distance(20);
  chassis.drive_distance(-20);
  Intake.stop();
  chassis.right_swing_to_angle(140);
  Intake.spin(fwd, 100, percent);
  chassis.drive_distance(26);
  chassis.drive_distance(-3);
  chassis.turn_to_angle(90);
  chassis.drive_distance(2);
  Flaps.set(true);
  chassis.drive_distance(-29);
  chassis.drive_distance(5);
  Flaps.set(false);
  chassis.turn_to_angle(-90);
  Intake.spin(reverse, 100, percent);
  chassis.drive_distance(-5);
  chassis.drive_distance(10);
  chassis.drive_distance(-10);
  
}

void left_offense(){
  chassis.set_heading(0);
  Flaps.set(true);
  Intake.spin(fwd, 100, percent);
  wait(0.15, sec);
  Flaps.set(false);
  chassis.set_drive_exit_conditions(1, 180, 1100);
  chassis.drive_distance(49.5);
  wait(0.55, sec);
  chassis.set_drive_exit_conditions(1, 180, 900);
  chassis.drive_distance(-10);
  Flaps.set(true);
  Intake.stop();
  chassis.left_swing_to_angle(80);
  Intake.spin(reverse, 100, percent);
  chassis.drive_distance(18);
  wait(0.3, sec);
  chassis.set_heading(0);
  Flaps.set(false);
  chassis.left_swing_to_angle(-45);
  chassis.set_drive_exit_conditions(1, 180, 1100);
  chassis.drive_distance(-41);
  chassis.set_drive_exit_conditions(1, 180, 900);
  chassis.right_swing_to_angle(90);
  chassis.drive_distance(-15);
  chassis.drive_distance(10);
  chassis.right_swing_to_angle(45);
  Flaps.set(true);
  chassis.drive_distance(12);
  chassis.set_swing_constants(12, .45, .001, 2, 15);
  chassis.right_swing_to_angle(35);
  chassis.right_swing_to_angle(20);
  chassis.set_swing_constants(8, .45, .001, 2, 15);
  Flaps.set(false);
  chassis.drive_distance(5);
  chassis.right_swing_to_angle(0);
  chassis.set_drive_exit_conditions(1, 180, 1100);
  chassis.drive_distance(34);
}

void skills_match(){

  chassis.set_heading(0);
  chassis.drive_distance(-16);
  chassis.right_swing_to_angle(45);
  chassis.drive_distance(-18);
  chassis.set_heading(0);
  chassis.right_swing_to_angle(-108);
  chassis.drive_distance(-13);
  
  int num_shot = 0;
  int start_time = vex::timer::system();
  while (num_shot < 45 && (vex::timer::system() - start_time < 48000)){
    while (Distance17.objectDistance(mm) >= 35){ // while catapult is not loaded
      printf("elapsed: %d\n", int(vex::timer::system()) - start_time); 
      if (vex::timer::system() - start_time >= 34000){
        break; // stop loop if time is >30 seconds
      }
      int degree = Rotation20.angle();
      if (degree > 52){
        Cata.stop(hold);
      }
      else if (degree < 60){
        Cata.spin(fwd, 100, percent); // change this percent to make it reload faster or slower
      }
      else {
        Cata.stop(hold);
      }
    }
    while (Distance17.objectDistance(mm) < 35){ // if catapult is loaded
      Cata.spin(fwd, 100, volt);
    }
    num_shot += 1;
  }
  Cata.stop(hold);
  chassis.left_swing_to_angle(-45);
  
  chassis.drive_distance(23);
  chassis.right_swing_to_angle(-90);
  
  Intake.spin(reverse, 100, percent);
  chassis.set_drive_exit_conditions(1.5, 180, 1600);
  chassis.drive_distance(75);
   chassis.set_drive_exit_conditions(1.5, 180, 900);
  chassis.right_swing_to_angle(-138);
  
  chassis.drive_distance(16);
  chassis.right_swing_to_angle(-180);
  chassis.set_drive_exit_conditions(1.5, 180, 1600);
  chassis.drive_distance(35);
  chassis.set_drive_exit_conditions(1.5, 180, 900);
  chassis.right_swing_to_angle(-80);
  chassis.drive_distance(-50);
  chassis.turn_to_angle(-135);
  Flaps.set(true);
  chassis.set_drive_exit_conditions(1.5, 180, 1100);
  chassis.drive_distance(50);
  chassis.set_drive_exit_conditions(1.5, 180, 900);
  chassis.left_swing_to_angle(-90);
  chassis.drive_distance(-10);
  Flaps.set(false);
  chassis.right_swing_to_angle(-25);
   chassis.set_drive_exit_conditions(1.5, 180, 1100);
  chassis.drive_distance(-60);
  chassis.turn_to_angle(-45);
  Flaps.set(true);
  chassis.drive_distance(50);
  chassis.set_drive_exit_conditions(1.5, 180, 900);
  chassis.right_swing_to_angle(-90);
  Flaps.set(false);
  chassis.drive_distance(-20);
  Flaps.set(true);
  chassis.drive_distance(28);
  chassis.set_drive_exit_conditions(1.5, 180, 1100);
  chassis.drive_distance(-40);
  chassis.drive_distance(48);
  chassis.drive_distance(-20);
  
  

}


void skills(){
  //left_awp();
  //right_4_ball();
  //right_5_ball();
  left_offense();
  //skills_match();
  //turn_test();
  //drive_test();

}
  
